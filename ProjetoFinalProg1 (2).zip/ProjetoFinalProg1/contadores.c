
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "contadores.h"

/*
 * CASO SEJA ADICIONADO UM NOVO ADMINISTRADOR INCREMENTA O NUMERO DO CONTADOR DE ADMINISTRADORES
 */
int contadorAdmin(CONT *cont){
    FILE *fp=NULL;

    cont->admin++;

    fp = fopen("C:\\Users\\User\\Desktop\\IPVC\\P!\\ProjetoFinalProg1\\contadores.dat", "wb");
    if(fp==NULL){printf("Erro ao abrir ficheiro!\n"); return -1;}
    fwrite(cont, sizeof(CONT),1,fp);
    fclose(fp);
    return 0;
}

int contadorAcionista(CONT *cont){
    FILE *fp=NULL;

    cont->acionistas++;

    fp = fopen("C:\\Users\\User\\Desktop\\IPVC\\P!\\ProjetoFinalProg1\\contadores.dat", "wb");
    if(fp==NULL){printf("Erro ao abrir ficheiro!\n"); return -1;}
    fwrite(cont, sizeof(CONT),1,fp);
    fclose(fp);
    return 0;
}

int contadorAta(CONT *cont){
    FILE *fp=NULL;

    cont->atas++;

    fp = fopen("C:\\Users\\User\\Desktop\\IPVC\\P!\\ProjetoFinalProg1\\contadores.dat", "wb");
    if(fp==NULL){printf("Erro ao abrir ficheiro!\n"); return -1;}
    fwrite(cont, sizeof(CONT),1,fp);
    fclose(fp);
    return 0;
}

/*
 * CARREGAR O VALOR DOS CONTADORES
 */
int carregarContador(CONT *cont){
    FILE *fp = NULL;
    fp = fopen("C:\\Users\\User\\Desktop\\IPVC\\P!\\ProjetoFinalProg1\\contadores.dat", "rb");
    if(fp==NULL){printf("Erro ao abrir ficheiro!\n"); return -1;}

    fread(cont, sizeof(CONT), 1, fp);
    fclose(fp);
    return 0;
}