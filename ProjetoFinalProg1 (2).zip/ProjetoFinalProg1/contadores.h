

#ifndef MAIN_C_CONTADORES_H
#define MAIN_C_CONTADORES_H

#endif //MAIN_C_CONTADORES_H

typedef struct contador{
    int admin;
    int acionistas;
    int atas;
}CONT;

int carregarContador(CONT *cont);
int contadorAdmin(CONT *cont);
int contadorAcionista(CONT *cont);
int contadorAta(CONT *cont);


