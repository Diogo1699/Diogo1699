/*
 *  PROJETO REALIZADO PARA A UC DE PROGRAMAÇÃO 1
 *  REALIZADO POR: TIAGO VALE e DIOGO ANDRADE
 */

#include <stdio.h>
#include <string.h>
#include "user.h"

int main(int argc, char *argv[]) {
    USERELEM *iniListaUser=NULL;
    ATAELEM *iniListaAta=NULL, *fimListaAta=NULL, *iniListaAtaClone=NULL, *fimListaAtaClone=NULL;
    CONT cont;
    char userName[50], password[50], retornaTipo[50], nomeCsv[100];
    int opcao;
    int ataReturn;

    cont.acionistas =0;
    cont.atas= 0;

    carregarListaUsers(&iniListaUser); // CARREGAR OS DADOS DO FICHEIRO PARA A LISTA
    carregarListaAtas(&iniListaAta, &fimListaAta);
    carregarContador(&cont); // CARREGA O VALOR EM QUE OS CONTADORES VAO

    //RECEBER O NOME DO FICHEIRO CSV
    if(argc<2){
        //printf("NENHUM FICHEIRO PASSADO POR ARGUMENTO DA LINHA DE COMANDOS!\n");
        return 0;
    } else{
        strcpy(nomeCsv, argv[1]);
        carregarListaFicheiroCsv(&iniListaAta, &fimListaAta, cont, nomeCsv);
        carregarContador(&cont); // CARREGA O VALOR EM QUE OS CONTADORES VAO
    }

    do {
        strcpy(retornaTipo,"asd"); //RESETAR O TIPO

        if (iniListaUser == NULL) {
            printf("==========================================================\n");
            printf("====== Criacao do primeiro Administrador do Sistema ======\n");
            printf("==========================================================\n");
            cont.admin = 0;
            criaAdmin(&iniListaUser, cont);
            contadorAdmin(&cont); // INCREMENTA O VALOR DO CONTADOR DE ADMINS
        }

        //carregarContador(&cont); // CARREGA O VALOR EM QUE OS CONTADORES VAO
        printf("========================= LOGIN =========================\n");
        printf("Insira o username:\n");
        scanf("%s", userName);
        printf("Insira a password:\n");
        scanf("%s", password);

        pesquisarUser(iniListaUser, userName, password,retornaTipo); // VERIFICAR SE EXISTE E RETORNAR O TIPO DO UTILIZADOR

        if (strcmp(retornaTipo, "administrador") == 0) {
            do {

                printf("========================= BEM VINDO ADMIN =========================\n");
                printf("1 - Registar novos utilizadores\n");
                printf("2 - Inserir ata\n");
                printf("3 - Alterar ata\n");
                printf("4 - Apagar ata\n");
                printf("5 - Pesquisar ata\n");
                printf("===================================================================\n");
                scanf("%i", &opcao);

                switch (opcao) {
                    case 1: {
                        printf("==================================================\n");
                        printf("1 - Inserir Administradores\n");
                        printf("2 - Inserir Acionistas\n");
                        scanf("%i", &opcao);
                        if (opcao == 1) {
                            criaAdmin(&iniListaUser, cont);
                            contadorAdmin(&cont); // INCREMENTA O VALOR DO CONTADOR DE ADMINS
                        }
                        if(opcao == 2){
                            criaAcionista(&iniListaUser, cont);
                            contadorAcionista(&cont);
                        }
                        break;
                    }
                    case 2: {
                        ataReturn=criaAta(&iniListaAta, cont, iniListaUser, &fimListaAta); //Isto é para apenas incrementar o contador das atas caso a ata seja criada...
                        if(ataReturn==0) { contadorAta(&cont); } else {printf("Ata nao criada!\n");}
                        break;
                    }
                    case 3:{
                        printf("==================================================\n");
                        printf("1 - Adicionar novo Acionista a ata\n");
                        printf("2 - Alterar a data da ata\n");
                        printf("3 - Alterar o local da assembleia da ata\n");
                        printf("4 - Alterar o texto da ata\n");
                        printf("5 - Alterar o estado da ata\n"); //so vai poder alterar as que estao em redação para assinatura, ou seja, enquanto esta em redacao pode adicionar novos acionistas, depois nao pode.
                        scanf("%i", &opcao);

                        switch(opcao){
                            case 1:{
                                adicionaAta(&iniListaAta, iniListaUser, &fimListaAta); //ADICIONAR UM NOVO ACIONISTA À ATA, PRECISA DA LISTA DOS USERS PARA SABER QUAIS ACIONISTAS EXISTEM..
                                break;
                            }

                            case 2:{
                                alteraDataAta(&iniListaAta, fimListaAta);
                                escreveListaAtas(fimListaAta);
                                break;
                            }

                            case 3:{
                                alteraLocalAta(&iniListaAta, fimListaAta);
                                escreveListaAtas(fimListaAta);
                                break;
                            }

                            case 4:{
                                alteraTextoAta(&iniListaAta, fimListaAta);
                                escreveListaAtas(fimListaAta);
                                break;
                            }

                            case 5:{
                                alteraEstadoAta(&iniListaAta, fimListaAta);
                                escreveListaAtas(fimListaAta);
                                break;
                            }
                        }
                        break;
                    }
                    case 4:{
                        apagarAta(&iniListaAta, &fimListaAta);
                        escreveListaAtas(fimListaAta);
                        break;
                    }

                    case 5:{
                        printf("=============================================================================================\n");
                        printf("1 - Listar atas por estado\n");
                        printf("2 - Listar assinaturas em falta de determinada ata\n");
                        printf("3 - Listar todas as atas de assembleias que tenham ocorrido depois de uma determinada data\n");
                        printf("4 - Listar todas as atas, ordenadas primeiro por estado e depois por data\n");
                        printf("5 - Pesquisar propostas as atas por local da assembleia a que diz respeito\n");
                        printf("6 - Escrever a ata no ficheiro de texto\n");
                        printf("7 - Gerar a listagem de atas ordenadas por quantidade de assinaturas em falta\n");
                        scanf("%i", &opcao);

                        switch(opcao){
                            case 1:{
                                listaAtaEstado(fimListaAta, iniListaAta);
                                break;
                            }
                            case 2: {
                                listaAssinaturasFalta(fimListaAta, iniListaAta);
                                break;
                            }
                            case 3:{
                                listaAtaData(fimListaAta);
                                break;
                            }

                            case 4:{
                                criaClone(&iniListaAtaClone, &fimListaAtaClone);
                                listaAtaOrdenadaEstado(iniListaAtaClone);
                                apagaAtaClone(&iniListaAtaClone, &fimListaAtaClone); //APAGAR OS ELEMENTOS PARA NAO CRIAR ELEMENTOS REPETIDOS
                                criaClone(&iniListaAtaClone, &fimListaAtaClone);
                                listaAtaOrdenadaData(iniListaAtaClone);
                                apagaAtaClone(&iniListaAtaClone, &fimListaAtaClone);
                                break;
                            }
                            case 5:{
                                pesquisaAtaAssembleia(fimListaAta, iniListaAta);
                                break;
                            }
                            case 6:{
                                escreveAtaFicheiro(fimListaAta, iniListaAta);
                                break;
                            }
                            case 7:{
                                criaClone(&iniListaAtaClone, &fimListaAtaClone);
                                ataOrdenadaQtdAssinatura(iniListaAtaClone);
                                apagaAtaClone(&iniListaAtaClone, &fimListaAtaClone);
                                break;
                            }
                        }
                        break;
                    }


                }
            }while(opcao != 0);

        } else if (strcmp(retornaTipo, "acionista") == 0) {
            do {
                printf("========================= BEM VINDO ACIONISTA =========================\n");
                printf("1 - Verificar se existe alguma ata que esteja habilitado a assinar\n");
                printf("0 - SAIR\n");
                printf("=======================================================================\n");
                scanf("%i", &opcao);

                if (opcao == 1) {
                    verificaAssinaturaAta(&iniListaAta, userName);
                    verificaConclusaoAta(&iniListaAta, fimListaAta);
                    escreveListaAtas(fimListaAta);
                    opcao=-1;
                }
                if (opcao==0){printf("A SAIR...\n");}

            }while(opcao != 1 && opcao != 0);


        } else { printf("Utilizador nao encontrado!\n"); }
    } while (strcmp(userName, "SAIR") != 0);
    return 0;
}