

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "user.h"

/*
 * CARREGAR OS UTILIZADORES PRESENTES NO FICHEIRO PARA A LISTA
*/
int carregarListaUsers(USERELEM **iniListaUser){
    FILE *fp = NULL;
    USERELEM *novo = NULL;

    novo = (USERELEM *) calloc(100, sizeof(USERELEM));

    if (novo == NULL) {
        printf("Out of Memory!\n");
        return -1;
    }

    fp = fopen("C:\\Users\\User\\Desktop\\IPVC\\P!\\ProjetoFinalProg1\\users.dat", "rb");
    novo->seguinte = NULL;
    if (fp==NULL){return 0;}

    while (fread(&(novo->node), sizeof(USERINFO), 1, fp) != 0) {
        if (*iniListaUser == NULL) {
            *iniListaUser = novo;
        } else {
            novo->seguinte = *iniListaUser; //O Inilista é so um ponteiro.....
            *iniListaUser = novo;
        }
        novo = novo->seguinte;
        novo = (USERELEM *) calloc(1, sizeof(USERELEM));
    }
    fclose(fp);

    return 0;
}

/*
 * INSERIR O PRIMEIRO ADMINISTRADOR DO PROGRAMA
*/
int criaAdmin(USERELEM **iniListaUser, CONT cont){
    USERELEM *novo=NULL;
    USERINFO admin;
    FILE *fp=NULL;
    char contAdmin[10];

    novo=(USERELEM *)calloc(1, sizeof(USERELEM));

    if (novo == NULL) { printf("Out of Memory!\n"); return -1;}

    printf("Insira o nome do Administrador: \n");
    scanf("%s", admin.nome);
    printf("Insira a password do Administrador: \n");
    scanf("%s", admin.password);

    //COLOCAR O ADMIN COM O NUMERO DO CONTADOR
    strcpy(admin.userName,"Admin");
    itoa(cont.admin,contAdmin,10); // Passar de inteiro para string
    strcat(admin.userName, contAdmin);

    //COLOCAR O TIPO ADMINISTRADOR
    strcpy(admin.tipo, "administrador");

    novo->node=admin;
    novo->seguinte=NULL;

    if (*iniListaUser==NULL){
    *iniListaUser=novo;
    } else{
    novo->seguinte=*iniListaUser;
    *iniListaUser=novo;
    }

    fp = fopen("C:\\Users\\User\\Desktop\\IPVC\\P!\\ProjetoFinalProg1\\users.dat", "ab");
    fwrite(&(novo->node), sizeof(USERINFO), 1, fp);
    fclose(fp);

    return 0;
}

/*
 * INSERIR UM ACIONISTA
*/
int criaAcionista(USERELEM **iniListaUser, CONT cont){
    USERELEM *novo=NULL;
    USERINFO acionista;
    FILE *fp=NULL;
    char contAcionista[10];

    novo=(USERELEM *)calloc(1, sizeof(USERELEM));

    if (novo == NULL) { printf("Out of Memory!\n"); return -1;}

    printf("Insira o nome do Acionista: \n");
    scanf("%s", acionista.nome);
    printf("Insira a password do Acionista: \n");
    scanf("%s", acionista.password);

    //COLOCAR O acionista COM O NUMERO DO CONTADOR
    strcpy(acionista.userName,"Acionista");
    itoa(cont.acionistas,contAcionista,10); // Passar de inteiro para string
    strcat(acionista.userName, contAcionista);

    //COLOCAR O TIPO acionista
    strcpy(acionista.tipo, "acionista");

    novo->node=acionista;
    novo->seguinte=NULL;

    if (*iniListaUser==NULL){
        *iniListaUser=novo;
    } else{
        novo->seguinte=*iniListaUser;
        *iniListaUser=novo;
    }

    fp = fopen("C:\\Users\\User\\Desktop\\IPVC\\P!\\ProjetoFinalProg1\\users.dat", "ab");
    fwrite(&(novo->node), sizeof(USERINFO), 1, fp);
    fclose(fp);

    return 0;
}


/*
 * PESQUISAR SE EXISTE O UTILIZADOR COM O NOME E A PASSWORD E RETORNAR O TIPO DESSE UTILIZADOR
*/
int pesquisarUser(USERELEM *iniListaUser, char userName[], char password[], char retornaTipo[]){
    USERELEM *aux=NULL;

    for(aux = iniListaUser; aux != NULL; aux = aux->seguinte){
        if((strcmp(aux->node.userName, userName) == 0) && (strcmp(aux->node.password, password) == 0)){
            strcpy(retornaTipo, aux->node.tipo);
        }
    }
    return 0;
}



/*
 * PARTE DAS ATAS
 */

/*
 * FUNÇÃO PARA CRIAR UMA ATA
 */

int criaAta(ATAELEM **iniListaAta, CONT cont, USERELEM *iniListaUser, ATAELEM **fimListaAta){
    ATAELEM *novo=NULL;
    ATAINFO ata;
    ATAELEM *aux2=NULL;
    FILE *fp=NULL;
    USERELEM *aux=NULL;
    int codigo=0;
    char userName[100];

    novo = (ATAELEM *) calloc(1, sizeof(ATAELEM));
    if (novo == NULL) {printf("Out of Memory!\n");return -1;}

    //NUMERAR A ATA SEQUENCIALMENTE
    ata.numero=cont.atas;

    //COLOCAR AINDA  NÃO ASSINADA, DEPOIS QUANDO ASSINAR PASSA A ASSINADO E QUANDO TADAS AS ATAS(VISTAS PELO Nº) ESTIVEREM ASSINADAS, O ESTADO PASSA A CONCLUIDA.
    strcpy(ata.assinatura, "NaoAssinado");

    do {
        fflush(stdin);
        printf("Insira o estado da ata: (para assinatura ou em redacao)\n"); //em redacao vai poder adicionar novos membros mais tarde, para assinatura so pode adicionar os que vai colocar agora...
        scanf("%[^\n]s", ata.estado);
    } while (strcmp(ata.estado, "para assinatura") != 0 && strcmp(ata.estado, "em redacao") != 0);

    printf("Insira o dia da ata\n");
    scanf("%02d", &ata.dia);
    printf("Insira o mes da ata\n");
    scanf("%02d", &ata.mes);
    printf("Insira o ano da ata\n");
    scanf("%d", &ata.ano);
    fflush(stdin);
    printf("Insira o local da ata:\n");
    scanf("%[^\n]s", ata.local);
    fflush(stdin);
    printf("Insira o texto da ata:\n");
    scanf("%[^\n]s", ata.texto);
    fflush(stdin);
    printf("Acionistas disponiveis:\n");

    /*
     * VAI RECEBER A LISTA DOS UTILIZADORES, E MOSTRAR QUAIS OS ACIONISTAS QUE ESTÃO REGISTADOS
     */

    for(aux = iniListaUser; aux != NULL; aux = aux->seguinte){
            if (strcmp(aux->node.tipo, "acionista") == 0) {
                printf("%s - %s\n", aux->node.userName, aux->node.nome);
            }
    }

    //ADICIONAR O ACIONISTA À LISTA E CONFIRMAR QUE NÃO É ADICIONADO MAIS DO QUE UMA VEZ
    do{
        printf("Inserir username do Acionista (escrever SAIR para nao inserir mais)\n");
        scanf("%s", userName);

        /*
         * VERIFICAR SE JÁ EXISTE
         */
        if(strcmp(userName, "SAIR")!=0) {
            for (aux = iniListaUser; aux != NULL; aux = aux->seguinte) {
                if (strcmp(aux->node.userName, userName) == 0 && strcmp(aux->node.tipo, "acionista") == 0) { //CASO O NOME USERNAME CORRESPONDA A ALGUM ACIONISTA PRESENTE NA LISTA DOS UTILIZADORES mas que seja acionista

                    //VERIFICAR SE O ACIONISTA JÁ SE ENCONTRA INSCRITO NA ATA.. VÊ O NUMERO DA ATA E VE SE JA EXISTE ALGUM NESSE NUMERO...
                    for(aux2=*iniListaAta; aux2!=NULL;aux2=aux2->seguinte) {
                        if (strcmp(aux2->node.listaDeAcionistas, userName) == 0 && aux2->node.numero == cont.atas) {
                            printf("O Acionista inserido ja esta presente na Ata!\n");
                            return -1;
                        }
                    }

                    strcpy(ata.listaDeAcionistas, userName);

                    novo->node = ata;
                    novo->seguinte = NULL;
                    novo->anterior = NULL;

                    if (*iniListaAta == NULL) {
                        *iniListaAta = novo;
                        *fimListaAta = novo;
                    } else {
                        novo->seguinte = *iniListaAta;
                        (*iniListaAta)->anterior=novo;
                        *iniListaAta = novo;
                    }

                    fp = fopen("C:\\Users\\User\\Desktop\\IPVC\\P!\\ProjetoFinalProg1\\atas.dat", "ab");
                    fwrite(&(novo->node), sizeof(ATAINFO), 1, fp);
                    fclose(fp);
                    codigo = 1;

                    //VOLTAR A ALOCAR MEMORIA PARA CRIAR O NOVO ACIONSISTA COM OS MESMOS DADOS QUE O ACIONISTA ANTERIOR
                    novo = (ATAELEM *) calloc(1, sizeof(ATAELEM));
                    if (novo == NULL) {printf("Out of Memory!\n");return -1;}

                }
            }
        }
    }while(strcmp(userName, "SAIR") != 0);

    if(codigo==1) { return 0; } else{return -1;} //Para saber se realmente escreveu algum acionista ou se simplesmente decidiu SAIR...
}

/*
 * CARREGAR A LISTA DA ATA
 */
int carregarListaAtas(ATAELEM **iniListaAta, ATAELEM **fimListaAta){
    FILE *fp = NULL;
    ATAELEM *novo =NULL;

    novo = (ATAELEM *)calloc(100,sizeof(ATAELEM)); //100

    if(novo==NULL){printf("Out of memory!\n"); return -1;}

    fp = fopen("C:\\Users\\User\\Desktop\\IPVC\\P!\\ProjetoFinalProg1\\atas.dat", "rb");
    novo->seguinte = NULL;
    novo->anterior = NULL;
    if (fp==NULL){return 0;}

    while (fread(&(novo->node), sizeof(ATAINFO), 1, fp) != 0) {
        if (*iniListaAta == NULL) {
            *iniListaAta = novo;
            *fimListaAta = novo;
        } else {
            novo->seguinte = *iniListaAta; //O Inilista é so um ponteiro.....
            (*iniListaAta)->anterior=novo;
            *iniListaAta = novo;
        }
        novo = (ATAELEM *) calloc(1, sizeof(ATAELEM));
    }
    fclose(fp);

    return 0;
}

/*
 * FUNÇÃO PARA LISTAR ATA POR ESTADO
 */

int listaAtaEstado(ATAELEM *fimListaAta, ATAELEM *iniListaAta){
    ATAELEM *aux=NULL, *aux2=NULL;
    int estado;
    int numero=0;
    char estadoAux[20];

    fflush(stdin);
    printf("Insira o estado das atas a pesquisar\n");
    printf("1 - em redacao\n");
    printf("2 - para assinatura\n");
    printf("3 - concluida\n");
    scanf("%i", &estado);

    if (estado ==1){strcpy(estadoAux, "em redacao");}
    if (estado ==2){strcpy(estadoAux, "para assinatura");}
    if (estado ==3){strcpy(estadoAux, "Concluida");}

    aux=fimListaAta;

    while(aux!=NULL){
        if(numero == aux->node.numero && strcmp(aux->node.estado, estadoAux)==0) {
            printf("\n\nATA %i - %s\n", aux->node.numero, aux->node.estado);
            printf("DATA: %i/%i/%i\n", aux->node.dia, aux->node.mes, aux->node.ano);
            printf("LOCAL: %s\n", aux->node.local);
            printf("TEXTO: %s\n", aux->node.texto);
            printf("Lista de acionistas presentes na Ata:\n");
            for(aux2=iniListaAta; aux2!=NULL; aux2=aux2->seguinte) {
                if(strcmp(aux2->node.estado, estadoAux)==0 && aux2->node.numero == numero){
                    printf("%s\n", aux2->node.listaDeAcionistas);
                }
            }

            numero++;
            aux = aux->anterior;
        } else if(numero > aux->node.numero){ //Caso o numero da ata volte a ser um numero mais pequeno, nao repete tudo de novo e salta para o anterior...
            aux = aux->anterior;
        } else {numero++;}
    }
    return 0;
}


/*
 * FUNÇÃO PARA ADICIONAR UM NOVO ACIONISTA À ATA
 */
int adicionaAta(ATAELEM **iniListaAta, USERELEM *iniListaUser, ATAELEM **fimListaAta){
    ATAELEM *aux=NULL;
    ATAELEM *novo=NULL;
    int numero=0, ata=0,valorReturn=0;
    ATAINFO ataInfo;
    USERELEM *aux2=NULL;
    char userName[50];
    FILE *fp=NULL;

    novo = (ATAELEM *) calloc(1, sizeof(ATAELEM));
    if (novo == NULL) {printf("Out of Memory!\n");return -1;}

    printf("Atas existentes: \n");

    aux=*fimListaAta;
    while(aux!=NULL){
        if(numero == aux->node.numero && strcmp(aux->node.estado, "em redacao")==0) {
            printf("ATA %i - %s\n", aux->node.numero, aux->node.estado);
            numero++;
            aux = aux->anterior;
        } else if(numero > aux->node.numero){ //Caso o numero da ata volte a ser um numero mais pequeno, nao repete tudo de novo e salta para o anterior...
            aux = aux->anterior;
        } else {numero++;}
    }

    printf("A qual ata deseja adicionar? (Inserir o numero da ata)\n");
    scanf("%i", &ata);

    for(aux=*iniListaAta; aux!=NULL; aux=aux->seguinte){
        if(ata==aux->node.numero && strcmp(aux->node.estado, "em redacao")==0){
            ataInfo.numero=ata;
            strcpy(ataInfo.estado, aux->node.estado);
            ataInfo.dia = aux->node.dia;
            ataInfo.mes = aux->node.mes;
            ataInfo.ano = aux->node.ano;
            strcpy(ataInfo.local, aux->node.local);
            strcpy(ataInfo.texto, aux->node.texto);
            strcpy(ataInfo.assinatura, "NaoAssinado");
            valorReturn=1; //Para confirmar que houve alguma ata com aquele numero e que esteja em redacao
        }
    }

    if(valorReturn==0){printf("A ata inserida nao existe ou ja nao esta em redacao!\n"); return -1;}

    //Agora mostra os acionistas
    printf("Acionistas existentes:\n");
    for(aux2 = iniListaUser; aux2 != NULL; aux2 = aux2->seguinte){
        if (strcmp(aux2->node.tipo, "acionista") == 0) {
            printf("%s - %s\n", aux2->node.userName, aux2->node.nome);
        }
    }

    printf("Inserir username do Acionista\n");
    scanf("%s", userName);

    /*
     * VERIFICAR SE JÁ EXISTE
     */
        for (aux2 = iniListaUser; aux2 != NULL; aux2 = aux2->seguinte) {
            if (strcmp(aux2->node.userName, userName) == 0 && strcmp(aux2->node.tipo, "acionista") == 0) { //CASO O NOME USERNAME CORRESPONDA A ALGUM ACIONISTA PRESENTE NA LISTA DOS UTILIZADORES
                //VERIFICAR SE O ACIONISTA JÁ SE ENCONTRA INSCRITO NA ATA.. VÊ O NUMERO DA ATA E VE SE JA EXISTE ALGUM NESSE NUMERO...
                for(aux=*iniListaAta; aux!=NULL;aux=aux->seguinte) {
                    if (strcmp(aux->node.listaDeAcionistas, userName) == 0 && aux->node.numero == ata) {
                        printf("O Acionista inserido ja esta presente na Ata!\n");
                        return -1;
                    }
                }

                strcpy(ataInfo.listaDeAcionistas, userName);

                novo->node = ataInfo;
                novo->seguinte = NULL;
                novo->anterior = NULL;

                if (*iniListaAta == NULL) {
                    *iniListaAta = novo;
                    *fimListaAta =novo;
                } else {
                    novo->seguinte = *iniListaAta;
                    (*iniListaAta)->anterior=novo;
                    *iniListaAta = novo;
                }

                fp = fopen("C:/Users/User/Desktop/IPVC/P!/ProjetoFinalProg1\\atas.dat", "ab");
                fwrite(&(novo->node), sizeof(ATAINFO), 1, fp);
                fclose(fp);
            }
        }

    return 0;
}

/*
 * VERIFICAR SE TEM ALGUMA ATA PARA ASSINAR
 */
int verificaAssinaturaAta(ATAELEM **iniListaAta, char userName[]){
    ATAELEM *aux=NULL;
    int numero, opcao;
    char acionista[20];
    char assinatura[50];
    time_t data_tempo;
    time(&data_tempo);

    const time_t timer=time(NULL); // RECEBER DATA E HORA PARA COLOCAR CASO ASSINE

    printf("Atas em que participa e que estao por assinar: \n");
    for(aux=*iniListaAta;aux!=NULL;aux=aux->seguinte){
        if(strcmp(userName, aux->node.listaDeAcionistas)==0 && strcmp(aux->node.estado, "para assinatura")==0 && strcmp(aux->node.assinatura, "NaoAssinado")==0){
            printf("\nATA NUMERO %d\n", aux->node.numero);
            printf("%s\n", aux->node.texto);
            printf("Dia:%02d Mes:%02d Ano:%d \n", aux->node.dia, aux->node.mes, aux->node.ano);
            printf("%s\n", aux->node.local);
        }
    }

    printf("Qual deseja verificar se pode assinar? (Insira o numero da ata)\n");
    scanf("%i", &numero);

    //VERIFICA QUEM É O PRIMEIRO ELEMENTO DA ATA QUE FALTA ASSINAR
    for(aux=*iniListaAta; aux!=NULL;aux=aux->seguinte){
        if(numero==aux->node.numero && strcmp(aux->node.estado, "para assinatura")==0 && strcmp(aux->node.assinatura, "NaoAssinado")==0){
            strcpy(acionista, aux->node.listaDeAcionistas);
            break;
        }
    }

    if(strcmp(acionista,userName)==0){
        printf("Deseja assinar a ata?\n");
        printf("1- Sim / 2- Nao\n");
        scanf("%i", &opcao);
        if(opcao==1){

            strcpy(assinatura, "Assinado");
            strcat(assinatura, " - ");
            strcat(assinatura, ctime(&timer));

            printf("%s\n", assinatura);

            for(aux=*iniListaAta; aux!=NULL; aux=aux->seguinte){
                if(numero==aux->node.numero && strcmp(userName, aux->node.listaDeAcionistas)==0){
                   strcpy(aux->node.assinatura, assinatura);
                   return 0;
                }
            }
        }
        if(opcao==2){
            printf("Ata nao assinada!\n");
            return 0;
        }
    }else{printf("Nao pode assinar a ata!\n"); return -1;}

    return 0;
}

/*
 * FUNÇÃO PARA ESCREVER A LISTA NO FICHEIRO
 */
int escreveListaAtas(ATAELEM *fimListaAta){
    FILE *fp=NULL;
    ATAELEM *aux=NULL;

    fp = fopen("C:/Users/User/Desktop/IPVC/P!/ProjetoFinalProg1\\atas.dat", "wb");
    if (fp == NULL){printf("Problemas ao criar o ficheiro\n");return -1;}

    //O CICLO É PARA O ANTERIOR POIS ASSIM MANTEM A LISTA DIREITA, SE FOSSE O INILISTA IRIA COLOCAR A LISTA AO CONTRARIO...
    for(aux = fimListaAta; aux != NULL; aux = aux->anterior){
        fwrite(&(aux->node), sizeof(ATAINFO), 1, fp);
    }

    fclose(fp);

    return 0;
}

/*
 * FUNÇÃO PARA REMOVER AS ATAS DA LISTA
 */
int apagarAta(ATAELEM **iniListaAta, ATAELEM **fimListaAta){
    ATAELEM *auxFim=NULL;
    ATAELEM *aux=*iniListaAta;
    ATAELEM *aux2=NULL;
    int num, confirmaAta=0;
    int numero = 0, contaAtas=0, i=0;

    auxFim=*fimListaAta;

    while(auxFim!=NULL){
        if(numero == auxFim->node.numero && strcmp(auxFim->node.estado, "em redacao")==0) {
            printf("ATA %i - %s\n", auxFim->node.numero, auxFim->node.estado);
            numero++;
            auxFim = auxFim->anterior;
        } else if(numero > auxFim->node.numero){ //Caso o numero da ata volte a ser um numero mais pequeno, nao repete tudo de novo e salta para o anterior...
            auxFim = auxFim->anterior;
        } else {numero++;}
    }

    printf("Insira o numero da ata a remover: \n");
    scanf("%d", &num);

    for(aux2=*iniListaAta; aux2!=NULL; aux2=aux2->seguinte){
        if(aux2->node.numero==num) { contaAtas++; } //Contar quantas atas existem (a mesma ata) para depois as remover todas
    }

    if(*iniListaAta==NULL){printf("Lista vazia!\n"); return -1;}

    for(i=0; i<=contaAtas; i++) { //Ciclo para apagar o numero de atas existentes (as mesmas atas).
        aux=*iniListaAta;
        while (aux != NULL && (num != aux->node.numero || strcmp(aux->node.estado, "em redacao") !=
                                                          0)) {
            aux = aux->seguinte;
        }
        if (aux == NULL) {
            if(confirmaAta==0) {
                printf("Ata nao encontrada!\n");
                return -1;
            }
            if(confirmaAta==1){ printf("Ata removida!\n"); return 0;}
        } //Percorreu todos e nao encontrou a ata, ou seja, não existe elemento num ou a lista é vazia

        if (aux->anterior == NULL) { //vai remover o 1º elemento
            *iniListaAta = aux->seguinte;
            confirmaAta=1; //Confirmar que houve pelo menos uma ata existente...
            if (*iniListaAta != NULL) { (*iniListaAta)->anterior = NULL; }
        } else { aux->anterior->seguinte = aux->seguinte; confirmaAta=1;}

        if (aux->seguinte == NULL) {//vai remover o ultimo elemento
            *fimListaAta = aux->anterior;
            confirmaAta=1; //Confirmar que houve pelo menos uma ata existente...
            if (*fimListaAta != NULL) { (*fimListaAta)->seguinte = NULL; }
        } else { aux->seguinte->anterior = aux->anterior; confirmaAta=1;}
        free(aux);
    }
    return 0;
}

/*
 * FUNÇÃO PARA ALTERAR A DATA DA ATA
 */
int alteraDataAta(ATAELEM **iniListaAta, ATAELEM *fimListaAta){
    ATAELEM *aux=NULL;
    ATAELEM *aux2=NULL;
    int numero=0, ata, valorReturn=0;
    int dia=0, mes=0, ano=0;

    aux=fimListaAta;
    printf("Atas disponiveis:\n");
    while(aux!=NULL){
        if(numero == aux->node.numero && strcmp(aux->node.estado, "em redacao")==0) {
            printf("ATA %i - %s\n", aux->node.numero, aux->node.estado);
            numero++;
            aux = aux->anterior;
        } else if(numero > aux->node.numero){ //Caso o numero da ata volte a ser um numero mais pequeno, nao repete tudo de novo e salta para o anterior...
            aux = aux->anterior;
        } else {numero++;}
    }

    printf("Insira o numero da ata que deseja alterar a data: \n");
    scanf("%d", &ata);

    printf("Insira a nova data:\n");
    printf("Dia:\n");
    scanf("%02d", &dia);
    printf("Mes:\n");
    scanf("%02d", &mes);
    printf("Ano:\n");
    scanf("%d", &ano);

    for(aux2=*iniListaAta; aux2!=NULL; aux2=aux2->seguinte){
        if(ata==aux2->node.numero && strcmp(aux2->node.estado, "em redacao")==0){
            aux2->node.dia=dia;
            aux2->node.mes=mes;
            aux2->node.ano=ano;
            valorReturn=1; //VERIFICAR SE HOUVE UMA QUE MUDOU PELO MENOS
        }
    }

    if(valorReturn==1){printf("Data alterada com sucesso!\n"); return 0;}
    if(valorReturn==0){printf("Data nao alterada!\n"); return -1;}
}

/*
 * FUNÇÃO PARA ALTERAR O LOCAL DA ATA
 */
int alteraLocalAta(ATAELEM **iniListaAta, ATAELEM *fimListaAta){
    ATAELEM *aux=NULL;
    ATAELEM *aux2=NULL;
    char local[50];
    int numero=0, ata, valorReturn=0;

    aux=fimListaAta;
    printf("Atas disponiveis:\n");
    while(aux!=NULL){
        if(numero == aux->node.numero && strcmp(aux->node.estado, "em redacao")==0) {
            printf("ATA %i - %s\n", aux->node.numero, aux->node.estado);
            numero++;
            aux = aux->anterior;
        } else if(numero > aux->node.numero){ //Caso o numero da ata volte a ser um numero mais pequeno, nao repete tudo de novo e salta para o anterior...
            aux = aux->anterior;
        } else {numero++;}
    }

    printf("Insira o numero da ata que deseja alterar o local: \n");
    scanf("%d", &ata);

    fflush(stdin);
    printf("Insira o novo Local da Assembleia:\n");
    scanf("%[^\n]s", local);

    for(aux2=*iniListaAta; aux2!=NULL; aux2=aux2->seguinte){
        if(ata==aux2->node.numero && strcmp(aux2->node.estado, "em redacao")==0){
            strcpy(aux2->node.local, local);
            valorReturn=1; //VERIFICAR SE HOUVE UMA QUE MUDOU PELO MENOS
        }
    }
    if(valorReturn==1){printf("Local alterado com sucesso!\n"); return 0;}
    if(valorReturn==0){printf("Local nao alterado!\n"); return -1;}
}

/*
 * FUNÇÃO PARA ALTERAR O TEXTO DA ATA
 */
int alteraTextoAta(ATAELEM **iniListaAta, ATAELEM *fimListaAta){
    ATAELEM *aux=NULL;
    ATAELEM *aux2=NULL;
    char texto[500];
    int numero=0, ata, valorReturn=0;

    aux=fimListaAta;
    printf("Atas disponiveis:\n");
    while(aux!=NULL){
        if(numero == aux->node.numero && strcmp(aux->node.estado, "em redacao")==0) {
            printf("ATA %i - %s\n", aux->node.numero, aux->node.estado);
            numero++;
            aux = aux->anterior;
        } else if(numero > aux->node.numero){ //Caso o numero da ata volte a ser um numero mais pequeno, nao repete tudo de novo e salta para o anterior...
            aux = aux->anterior;
        } else {numero++;}
    }

    printf("Insira o numero da ata que deseja alterar o texto: \n");
    scanf("%d", &ata);

    fflush(stdin);
    printf("Insira o novo texto da ata:\n");
    scanf("%[^\n]s", texto);

    for(aux2=*iniListaAta; aux2!=NULL; aux2=aux2->seguinte){
        if(ata==aux2->node.numero && strcmp(aux2->node.estado, "em redacao")==0){
            strcpy(aux2->node.texto, texto);
            valorReturn=1; //VERIFICAR SE HOUVE UMA QUE MUDOU PELO MENOS
        }
    }
    if(valorReturn==1){printf("Texto alterado com sucesso!\n"); return 0;}
    if(valorReturn==0){printf("Texto nao alterado!\n"); return -1;}
}

/*
 * FUNÇÃO PARA ALTERAR O ESTADO DA ATA
 */

int alteraEstadoAta(ATAELEM **iniListaAta, ATAELEM *fimListaAta){
    ATAELEM *aux=NULL;
    ATAELEM *aux2=NULL;
    int numero=0, ata, valorReturn=0, opcao=0;

    aux=fimListaAta;
    printf("Atas disponiveis:\n");
    while(aux!=NULL){
        if(numero == aux->node.numero && strcmp(aux->node.estado, "em redacao")==0) {
            printf("ATA %i - %s\n", aux->node.numero, aux->node.estado);
            numero++;
            aux = aux->anterior;
        } else if(numero > aux->node.numero){ //Caso o numero da ata volte a ser um numero mais pequeno, nao repete tudo de novo e salta para o anterior...
            aux = aux->anterior;
        } else {numero++;}
    }

    printf("Insira o numero da ata que deseja alterar o estado para assinado: \n");
    scanf("%d", &ata);


    printf("ATENCAO! APOS ALTERAR O ESTADO DA ATA NAO E POSSIVEL REVERTER O MESMO!\n");
    printf("Tem a certeza que deseja alterar o estado da Ata %d para assinado?\n", ata);
    do {
        printf("1 - SIM\n");
        printf("2 - NAO\n");
        scanf("%d", &opcao);

        if (opcao == 1) {
            for (aux2 = *iniListaAta; aux2 != NULL; aux2 = aux2->seguinte) {
                if (ata == aux2->node.numero && strcmp(aux2->node.estado, "em redacao") == 0) {
                    strcpy(aux2->node.estado, "para assinatura");
                    valorReturn = 1; //VERIFICAR SE HOUVE UMA QUE MUDOU PELO MENOS
                }
            }
            if (valorReturn == 1) {
                printf("Estado alterado com sucesso!\n");
                return 0;
            }
            if (valorReturn == 0) {
                printf("Estado nao alterado, ata nao encontrada ou nao esta em redacao!\n");
                return -1;
            }
        } else if (opcao == 2) {
            printf("Estado nao alterado!\n");
            return 0;
        }
    }while(opcao != 1 && opcao !=2);
    return 0;
}

/*
 * FUNÇÃO PARA VEERIFICAR SE TODOS OS ACIONISTAS JÁ ASSINARAM A ATA E PASSAR A MESMA AO ESTADO CONCLUIDA
 */

int verificaConclusaoAta(ATAELEM **iniListaAta, ATAELEM *fimListaAta){
    ATAELEM *aux=NULL, *aux2=NULL;
    int ataNum=0, auxAssinatura=0, numero=0;

    aux2=fimListaAta;

    //CALCULA QUANTAS ATAS EXISTEM
    while(aux2!=NULL){
        if(numero == aux2->node.numero) {
            numero++;
            aux2 = aux2->anterior;
        } else if(numero > aux2->node.numero){ //Caso o numero da ata volte a ser um numero mais pequeno, nao repete tudo de novo e salta para o anterior...
            aux2 = aux2->anterior;
        }else {numero++;}
    }

    do {
        // VERIFICA SE TODOS OS ELEMENTOS DENTRO DA ATA NºX ESTÁ ASSINADO, CASO ESTEJA O AUX ASSINATURA FICA A 1.
        for (aux = *iniListaAta; aux != NULL; aux = aux->seguinte) {
            if (aux->node.numero == ataNum) {
                //A COMPARAÇÃO COM O \0 É PARA CASO TENHA SIDO UMA DAS ATAS PASSADAS POR ARGUMENTO DA LINHA DE COMANDOS
                if (strcmp(aux->node.assinatura, "NaoAssinado") != 0 && strcmp(aux->node.listaDeAcionistas, "\0")!=0) { //AQUI NÃO É SER IGUAL A ASSINADO POIS A ASSINATURA TEM UMA DATA E HORA QUE DIFERE ENTRE OS ACIONISTAS.
                    auxAssinatura = 1;
                }else if(strcmp(aux->node.assinatura, "NaoAssinado")==0){
                    auxAssinatura = 0;
                    break;
                } // CASO HAJA UM ACIONISTA QUE NÃO ESTEJA ASSINADO SAI FORA DO CICLO
            }
        }

        // CASO O AUX ESTIVER A 1 SIGNIFICA QUE TODOS OS ACIONISTAS JA TINHAM ASSINADO LOGO A ATA PASSA A CONLCUIDA
        if (auxAssinatura == 1) {
            for (aux = *iniListaAta; aux != NULL; aux = aux->seguinte) {
                if (aux->node.numero == ataNum) {
                    strcpy(aux->node.estado, "Concluida");
                }
            }
        }
        auxAssinatura=0;
        ataNum++;//VERIFICA A PROXIMA ATA
    }while(ataNum <= numero);  // REALIZA O NUMERO TOTAL DE ATAS EXISTENTES

    return 0;
}

/*
 * FUNÇÃO PARA LISTAR ASSINATURAS EM FALTA DE DETERMINADA ATA
 */
void listaAssinaturasFalta(ATAELEM *fimListaAta, ATAELEM *iniListaAta){
    ATAELEM *aux=NULL, *aux2=NULL;
    int numero=0, opcao=0, confirmacao=0;

    aux=fimListaAta;
    printf("Atas disponiveis:\n");
    while(aux!=NULL){
        if(numero == aux->node.numero && strcmp(aux->node.estado, "Concluida")!=0) {
            printf("ATA %i - %s\n", aux->node.numero, aux->node.estado);
            numero++;
            aux = aux->anterior;
        } else if(numero > aux->node.numero){ //Caso o numero da ata volte a ser um numero mais pequeno, nao repete tudo de novo e salta para o anterior...
            aux = aux->anterior;
        } else {numero++;}
    }

    printf("Qual ata deseja verificar as assinaturas em falta?\n");
    scanf("%d", &opcao);

    //Mostrar todos os acionistas que nao tem a assinatura da determinada ata...
    for(aux2=iniListaAta; aux2!=NULL; aux2=aux2->seguinte){
        if(aux2->node.numero==opcao && strcmp(aux2->node.assinatura, "NaoAssinado")==0){
            printf("O %s ainda nao assinou!\n", aux2->node.listaDeAcionistas);
            confirmacao=1; //Caso coloque uma ata que não existe ou já está concluida
        }
    }
    if(confirmacao==0){printf("Ata nao encontrada ou ja esta concluida!\n");} //Caso coloque uma ata que não existe ou já está concluida
}

/*
 * FUNÇÃO PARA LISTAR AS ATAS QUE TENHAM OCORRIDO APOS DETERMINADA DATA
 */
void listaAtaData(ATAELEM *fimListaAta){
    int dia, mes,ano, numero=0;
    ATAELEM *aux=NULL;

    printf("== LISTAR ATAS APOS DETERMINADA DATA ==\n");
    printf("Insira o dia:\n");
    scanf("%02d", &dia);
    printf("Insira o mes:\n");
    scanf("%02d", &mes);
    printf("Insira o ano\n");
    scanf("%d", &ano);


    printf("ATAS APOS %02d/%02d/%d :\n", dia,mes,ano);
    aux=fimListaAta;

    while(aux!=NULL){
        if(numero == aux->node.numero) {
            if(ano<aux->node.ano){
                printf("ATA No %d DATA:%02d/%02d/%d\n", aux->node.numero, aux->node.dia, aux->node.mes, aux->node.ano);
            }
            if(ano==aux->node.ano && mes < aux->node.mes){
                printf("ATA No %d DATA:%02d/%02d/%d\n", aux->node.numero, aux->node.dia, aux->node.mes, aux->node.ano);
            }
            if(ano==aux->node.ano && mes == aux->node.mes && dia < aux->node.dia){
                printf("ATA No %d DATA:%02d/%02d/%d\n", aux->node.numero, aux->node.dia, aux->node.mes, aux->node.ano);
            }
            numero++;
            aux = aux->anterior;
        } else if(numero > aux->node.numero){ //Caso o numero da ata volte a ser um numero mais pequeno, nao repete tudo de novo e salta para o anterior
            aux = aux->anterior;
        }else {numero++;}
    }
}

/*
 * FUNÇÃO QUE ESCREVE A ATA NO FICHEIRO DE TEXTO
 */
int escreveAtaFicheiro(ATAELEM *fimListaAta, ATAELEM *iniListaAta){
    ATAELEM *aux=NULL, *aux2=NULL;
    int numero=0, ata=0;
    FILE *fp=NULL;
    char sAta[10], caminho[100];

    aux=fimListaAta;
    printf("Atas disponiveis:\n");
    while(aux!=NULL){
        if(numero == aux->node.numero ) { //&& strcmp(aux->node.estado, "Concluida")!=0 && "em redacao".... se so escrever as atas que estao para assinatura??...
            printf("ATA %i - %s\n", aux->node.numero, aux->node.estado);
            numero++;
            aux = aux->anterior;
        } else if(numero > aux->node.numero){ //Caso o numero da ata volte a ser um numero mais pequeno, nao repete tudo de novo e salta para o anterior...
            aux = aux->anterior;
        } else {numero++;}
    }

    printf("Insira o numero da ata a escrever no ficheiro:\n");
    scanf("%d", &ata);

    //Converter o numero da ata escolhida em string
    itoa(ata, sAta, 10);

    strcpy(caminho, "C:/Users/User/Desktop/IPVC/P!/ProjetoFinalProg1\\");
    strcat(sAta, "-ATA.txt");
    strcat(caminho, sAta);

    for(aux=fimListaAta; aux!=NULL; aux=aux->anterior){
        if(ata==aux->node.numero){
            fp=fopen(caminho, "w");
            if(fp==NULL){printf("Erro ao abrir o ficheiro!\n"); return -1;}
            fprintf(fp, "\t\tATA No %d\nDATA: %02d/%02d/%d\nLOCAL: %s\n TEXTO: %s\n \nASSINATURAS", aux->node.numero, aux->node.dia, aux->node.mes, aux->node.ano
            , aux->node.local, aux->node.texto);

            //ESCREVER OS ESPAÇOS PARA OS ASSIONISTAS ASSINAR OU ESCREVER A ASSINATURA DO ACIONISTA COM A DATA E HORA DE QUANDO ASSINOU
            for(aux2=iniListaAta; aux2!=NULL; aux2=aux2->seguinte){
                if(aux2->node.numero==ata && strcmp(aux2->node.assinatura, "NaoAssinado")==0) { fprintf(fp, "\n%s ________________________\n", aux2->node.listaDeAcionistas); }
                else if (aux2->node.numero == ata) {fprintf(fp, "\n %s - %s\n", aux2->node.listaDeAcionistas, aux2->node.assinatura);}
            }

            fclose(fp);
            return 0;
        }
    }
    return 0;
}

/*
 * FUNÇÃO PARA PESQUISAR AS ATAS POR LOCAL DE ASSEMBLEIA A QUE DIZ RESPEITO
 */

int pesquisaAtaAssembleia(ATAELEM *fimListaAta, ATAELEM *iniListaAta) {
    ATAELEM *aux = NULL;
    ATAELEM *aux2 = NULL;
    int numero = 0, confirma=0;
    char assembleia[50];

    fflush(stdin);
    printf("Insira o nome da assembleia a pesquisar:\n");
    scanf("%[^\n]s", assembleia);

    //CICLO PARA PESQUISAR AS ATAS QUE PERTENCEM AQUELA ASSEMBLEIA
    aux = fimListaAta;
    numero = 0;
    while (aux != NULL) {
        if (numero == aux->node.numero && strcmp(assembleia, aux->node.local) == 0) {
            printf("\n\nATA %i - %s\n", aux->node.numero, aux->node.estado);
            printf("DATA: %i/%i/%i\n", aux->node.dia, aux->node.mes, aux->node.ano);
            printf("LOCAL: %s\n", aux->node.local);
            printf("TEXTO: %s\n", aux->node.texto);
            printf("LISTA DE ACIONISTAS:\n");

            for (aux2 = iniListaAta; aux2 != NULL; aux2 = aux2->seguinte) {
                if (aux2->node.numero == numero) {
                    printf("ACIONISTA: %s\n", aux2->node.listaDeAcionistas);
                }
            }
            confirma=1; //CONFIRMA QUE ENCONTROU PELO MENOS UMA ASSEMBLEIA
            numero++;
            aux = aux->anterior;
        } else if (numero >
                   aux->node.numero) { //Caso o numero da ata volte a ser um numero mais pequeno, nao repete tudo de novo e salta para o anterior...
            aux = aux->anterior;
        } else { numero++; }
    }

    if(confirma==0) { printf("Assembleia nao encontrada!\n"); return -1;}
    return 0;
}

/*
 * FUNÇÃO PARA CRIAR O CLONE DA LISTA, CLONE UTILIZADO PARA FICAR COM AS LISTAS ORDENADAS...
 */

int criaClone(ATAELEM **iniListaAtaClone, ATAELEM **fimListaAtaClone){

    FILE *fp = NULL;
    ATAELEM *novo =NULL;

    novo = (ATAELEM *)calloc(100,sizeof(ATAELEM)); //100

    if(novo==NULL){printf("Out of memory!\n"); return -1;}

    fp = fopen("C:/Users/User/Desktop/IPVC/P!/ProjetoFinalProg1\\atas.dat", "rb");
    novo->seguinte = NULL;
    novo->anterior = NULL;
    if (fp==NULL){return 0;}

    while (fread(&(novo->node), sizeof(ATAINFO), 1, fp) != 0) {
        if (*iniListaAtaClone == NULL) {
            *iniListaAtaClone = novo;
            *fimListaAtaClone = novo;
        } else {
            novo->seguinte = *iniListaAtaClone; //O Inilista é so um ponteiro.....
            (*iniListaAtaClone)->anterior=novo;
            *iniListaAtaClone = novo;
        }
        novo = (ATAELEM *) calloc(1, sizeof(ATAELEM));
    }
    fclose(fp);

    return 0;
}

/*
 * FUNÇÃO PARA APAGAR OS ELEMENTOS DA LISTA CLONE PARA NAO OS VOLTAR A COLOCAR REPETIDOS
 */
int apagaAtaClone(ATAELEM **iniListaAtaClone, ATAELEM **fimListaAtaClone){
    ATAELEM *aux=*iniListaAtaClone;

    if(*iniListaAtaClone==NULL){printf("Lista vazia!\n"); return -1;}

    aux=*iniListaAtaClone;
    while (aux != NULL) {
        aux=*iniListaAtaClone;
        if (aux == NULL) {return 1;}                    //PERCORREU TODOS E NÃO ENCONTROU A ATA

        if (aux->anterior == NULL) {                    //REMOVE O 1º ELEMENTO
            *iniListaAtaClone = aux->seguinte;

            if (*iniListaAtaClone != NULL) { (*iniListaAtaClone)->anterior = NULL; }
        } else { aux->anterior->seguinte = aux->seguinte;}

        if (aux->seguinte == NULL) {                    //REMOVE O ULTIMO ELEMENTO
            *fimListaAtaClone = aux->anterior;

            if (*fimListaAtaClone != NULL) { (*fimListaAtaClone)->seguinte = NULL; }
        } else { aux->seguinte->anterior = aux->anterior; }
        free(aux);
    }
    return 0;
}

/*
 * FUNÇÃO PARA ORDENAR AS ATAS POR ESTADO E LISTAR E DEPOIS ORDENAR POR DATA E LISTAR
 */

void listaAtaOrdenadaData(ATAELEM *iniListaAtaOrdenada){
    ATAELEM *aux=iniListaAtaOrdenada;
    int i;

    while(aux!=NULL){
        ATAELEM *aux2= aux->seguinte;
        while(aux2!=NULL){
            if(aux->node.ano > aux2->node.ano){
                ATAINFO auxDia = aux->node;
                aux->node = aux2->node;
                aux2->node = auxDia;
            }
            if(aux->node.ano == aux2->node.ano && aux->node.mes > aux2->node.mes){
                ATAINFO auxDia = aux->node;
                aux->node = aux2->node;
                aux2->node = auxDia;
            }
            if(aux->node.ano == aux2->node.ano && aux->node.mes == aux2->node.mes && aux->node.dia > aux2->node.dia){
                ATAINFO auxDia = aux->node;
                aux->node = aux2->node;
                aux2->node = auxDia;
            }
            aux2 = aux2->seguinte;
        }
        aux = aux->seguinte;
    }

    //INICIALIZAR CADA VALOR DO ARRAY A -1 PARA NAO RECEBER NUMEROS ALEATORIOS
    int j[100];
    for(i=0; i<100; i++){j[i]=-1;}

    i=0;
    printf("ATAS ORDENADAS POR DATA: \n");
    for(aux = iniListaAtaOrdenada; aux != NULL; aux = aux->seguinte) {
        int codigo=0;

        //CASO O NUMERO JÁ TENHA SIDO INSERIDO E JÁ ESTEJA NO ARRAY
        for(int k=0; k<100; k++){if(aux->node.numero == j[k]){codigo=1;}}

        if(codigo==0) {
            printf("Ata %d - DATA %02d/%02d/%d\n", aux->node.numero, aux->node.dia, aux->node.mes, aux->node.ano);
            printf("\n");
            j[i]=aux->node.numero;
        }
        i++;
    }
}

void listaAtaOrdenadaEstado(ATAELEM *iniListaAtaOrdenada){
    ATAELEM *aux=NULL;
    int i=0;

    aux=iniListaAtaOrdenada;
    while(aux!=NULL){
        ATAELEM *aux2= aux->seguinte;
        while(aux2!=NULL){
            if(strcmp(aux->node.estado, aux2->node.estado) >0){
                ATAINFO auxDia = aux->node;
                aux->node = aux2->node;
                aux2->node = auxDia;
            }
            aux2 = aux2->seguinte;
        }
        aux = aux->seguinte;
    }

    //INICIALIZAR CADA VALOR DO ARRAY A -1 PARA NAO RECEBER NUMEROS ALEATORIOS
    int j[100];
    for(i=0; i<100; i++){j[i]=-1;}

    i=0;
    printf("ATAS ORDENADAS POR ESTADO: \n");
    for(aux = iniListaAtaOrdenada; aux != NULL; aux = aux->seguinte) {
        int codigo=0;

        //CASO O NUMERO JÁ TENHA SIDO INSERIDO E JÁ ESTEJA NO ARRAY
        for(int k=0; k<100; k++){if(aux->node.numero == j[k]){codigo=1;}}

        if(codigo==0) {
            printf("Ata %d - Estado: %s\n", aux->node.numero, aux->node.estado);
            printf("\n");
            j[i]=aux->node.numero;
        }
        i++;
    }
}

void ataOrdenadaQtdAssinatura(ATAELEM *iniListaAtaOrdenada){
    ATAELEM *aux=NULL;
    int ata[100];
    int numero=0, cont=0;
    int i=0;

    //CONTAR O NUMERO DE ATAS EXISTENTES
    for(aux=iniListaAtaOrdenada; aux!=NULL; aux=aux->seguinte){cont++;}


    //GUARDAR O NUMERO DA ATA E O NUMERO DE NAO ASSINADOS QUE CONTEM
    ata[i]=0;
    do {
        for (aux = iniListaAtaOrdenada; aux != NULL; aux = aux->seguinte) {
            if (aux->node.numero == numero && strcmp(aux->node.assinatura, "NaoAssinado") == 0) {
                ata[i]=ata[i]+1;
            }
        }
        i++;
        ata[i]=0;
        numero++;
    }while(numero < 100);

    // LOOP PARA DAR O VALOR DO NUMERO DE NAO ASSINADOS A CADA ATA
    for(i=0; i<100; i++) {
        for (aux = iniListaAtaOrdenada; aux != NULL; aux = aux->seguinte) {
            if(aux->node.numero==i) { aux->node.numeroNaoAssinados = ata[i]; }
        }
    }

    //ORDENAR AS ATAS PELO NUMERO DE NAO ASSINATURAS
    aux=iniListaAtaOrdenada;
    while(aux!=NULL){
        ATAELEM *aux3= aux->seguinte;
        while(aux3!=NULL){
            if(aux->node.numeroNaoAssinados > aux3->node.numeroNaoAssinados){
                ATAINFO auxDia = aux->node;
                aux->node = aux3->node;
                aux3->node = auxDia;
            }
            aux3 = aux3->seguinte;
        }
        aux = aux->seguinte;
    }

    //INICIALIZAR CADA VALOR DO ARRAY A -1 PARA NAO RECEBER NUMEROS ALEATORIOS
    int j[100];
    for(i=0; i<100; i++){j[i]=-1;}

    i=0;
    printf("ATAS ORDENADAS POR QUANTIDADE DE ASSINATURAS EM FALTA: \n");
    for(aux = iniListaAtaOrdenada; aux != NULL; aux = aux->seguinte) {
        int codigo=0;

        for(int k=0; k<100; k++){if(aux->node.numero == j[k]){codigo=1;}} //CASO O NUMERO JÁ TENHA SIDO INSERIDO E JÁ ESTEJA NO ARRAY

        if(codigo==0) {
            printf("Ata %d - Assinaturas em falta: %d\n", aux->node.numero, aux->node.numeroNaoAssinados);
            printf("\n");
            j[i]=aux->node.numero;
        }
        i++;
    }
}

/*
 * FUNÇÃO PARA CARREGAR OS DADOS DO FICHEIRO CSV PARA A LISTA
 */

int carregarListaFicheiroCsv(ATAELEM **iniListaAta, ATAELEM **fimListaAta, CONT cont, char nomeCsv[]){
    ATAINFO ata;
    ATAELEM *novo=NULL;
    FILE *fp=NULL, *ficheiro=NULL;
    char linha[100], *aux;

    fp=fopen(nomeCsv, "r");
    if(fp==NULL){printf("Ocorreu um erro ao abrir o ficheiro Csv\n"); return -1;}


    while(fgets(linha,100,fp)!=NULL){
        //NUMERAR A ATA SEQUENCIALMENTE
        ata.numero=cont.atas;

        strcpy(ata.estado, "em redacao");
        strcpy(ata.listaDeAcionistas, "\0");
        strcpy(ata.assinatura, "\0");
        strcpy(ata.texto, "\0");
        ata.numeroNaoAssinados=0;

        aux = strtok(linha, "/");
        ata.dia = atoi(aux);
        aux = strtok(NULL, "/"); // NULL PARA SEGUIR EM FRENTE AO INVÉS DE VOLTAR AO INICIO DA LINHA
        ata.mes = atoi(aux);
        aux = strtok(NULL, ";");
        ata.ano = atoi(aux);
        aux = strtok(NULL, "\n");
        strcpy(ata.local, aux);

        // CRIAR NOVO ELEMENTO
        novo = (ATAELEM *) calloc(1, sizeof(ATAELEM));
        if (novo == NULL) {printf("Out of Memory!\n");return -1;}

        novo->node = ata;
        novo->seguinte = NULL;
        novo->anterior = NULL;

        if (*iniListaAta == NULL) {
            *iniListaAta = novo;
            *fimListaAta = novo;
        } else {
            novo->seguinte = *iniListaAta;
            (*iniListaAta)->anterior=novo;
            *iniListaAta = novo;
        }

        ficheiro = fopen("C:/Users/User/Desktop/IPVC/P!/ProjetoFinalProg1\\atas.dat", "ab");
        fwrite(&(novo->node), sizeof(ATAINFO), 1, ficheiro);
        fclose(ficheiro);

        contadorAta(&cont);
    }
    fclose(fp);
    return 0;
}