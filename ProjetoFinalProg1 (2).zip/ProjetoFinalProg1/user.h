

#ifndef MAIN_C_USER_H
#define MAIN_C_USER_H

#endif //MAIN_C_USER_H

#include "contadores.h"

/*
 * FUNÇÕES SOBRE OS UTILIZADORES
*/

typedef struct utilizador{
    char userName[50];
    char nome[50];
    char password[50];
    char tipo[50];
}USERINFO;

typedef struct userElem{
    USERINFO node;
    struct userElem *seguinte;
}USERELEM;

int carregarListaUsers(USERELEM **iniListaUser);
int pesquisarUser(USERELEM *iniListaUser, char userName[], char password[], char retornaTipo[]);
int criaAdmin(USERELEM **iniListaUser, CONT cont);
int criaAcionista(USERELEM **iniListaUser, CONT cont);

/*
 *  PARTE DAS ATAS.C
 */

typedef struct ata{
    int numero;
    int dia, mes, ano;
    char local[50];
    char texto[500];
    char listaDeAcionistas[50];
    char estado[20];
    char assinatura[50];
    int numeroNaoAssinados;
}ATAINFO;

typedef struct ataElem{
    ATAINFO node;
    struct ataElem *seguinte;
    struct ataElem *anterior;
}ATAELEM;

int criaAta(ATAELEM **iniListaAta, CONT cont, USERELEM *iniListaUser, ATAELEM **fimListaAta);
int carregarListaAtas(ATAELEM **iniListaAta, ATAELEM **fimListaAta);
int listaAtaEstado(ATAELEM *fimListaAta, ATAELEM *iniListaAta);
int adicionaAta(ATAELEM **iniListaAta, USERELEM *iniListaUser, ATAELEM **fimListaAta);
int verificaAssinaturaAta(ATAELEM **iniListaAta, char userName[]);
int escreveListaAtas(ATAELEM *fimListaAta);
int apagarAta(ATAELEM **iniListaAta, ATAELEM **fimListaAta);
int alteraDataAta(ATAELEM **iniListaAta, ATAELEM *fimListaAta);
int alteraLocalAta(ATAELEM **iniListaAta, ATAELEM *fimListaAta);
int alteraTextoAta(ATAELEM **iniListaAta, ATAELEM *fimListaAta);
int alteraEstadoAta(ATAELEM **iniListaAta, ATAELEM *fimListaAta);
int verificaConclusaoAta(ATAELEM **iniListaAta, ATAELEM *fimListaAta);
void listaAssinaturasFalta(ATAELEM *fimListaAta, ATAELEM *iniListaAta);
void listaAtaData(ATAELEM *fimListaAta);
int escreveAtaFicheiro(ATAELEM *fimListaAta, ATAELEM *iniListaAta);
int pesquisaAtaAssembleia(ATAELEM *fimListaAta, ATAELEM *iniListaAta);
void listaAtaOrdenadaData(ATAELEM *iniListaAtaOrdenada);
int criaClone(ATAELEM **iniListaAtaClone, ATAELEM **fimListaAtaClone);
int apagaAtaClone(ATAELEM **iniListaAtaClone, ATAELEM **fimListaAtaClone);
void listaAtaOrdenadaEstado(ATAELEM *iniListaAtaOrdenada);
void ataOrdenadaQtdAssinatura(ATAELEM *iniListaAtaOrdenada);
int carregarListaFicheiroCsv(ATAELEM **iniListaAta, ATAELEM **fimListaAta, CONT cont, char nomeCsv[]);